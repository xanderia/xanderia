self.__precacheManifest = [
  {
    "revision": "5c6e1767b32243f71cd4",
    "url": "/shop-playground/static/js/app.ed549a49.chunk.js"
  },
  {
    "revision": "22a78805cdc1e86da94e",
    "url": "/shop-playground/static/js/runtime~app.dab21698.js"
  },
  {
    "revision": "2d152c8604568f05221e",
    "url": "/shop-playground/static/js/2.8feb998c.chunk.js"
  },
  {
    "revision": "6165c9d7a2e729ba57b23dd93add5366",
    "url": "/shop-playground/static/media/back-icon-mask.6165c9d7.png"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/shop-playground/./fonts/AntDesign.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/shop-playground/./fonts/Entypo.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/shop-playground/./fonts/Feather.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/shop-playground/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/shop-playground/./fonts/Foundation.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/shop-playground/./fonts/Ionicons.ttf"
  },
  {
    "revision": "d15c1216957060fac577af6151fb8cfe",
    "url": "/shop-playground/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/shop-playground/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/shop-playground/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/shop-playground/serve.json"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/shop-playground/favicon.ico"
  },
  {
    "revision": "f8ec03c023e9e57caad88d688701c413",
    "url": "/shop-playground/manifest.json"
  },
  {
    "url": "/shop-playground/assets/icons/icon_192x192.76332cb067bda20ca435095f5b11efb9.png"
  },
  {
    "url": "/shop-playground/assets/icons/icon_180x180.c3850292a0b45b53fa95eecfb5ef4ee5.png"
  },
  {
    "url": "/shop-playground/assets/icons/icon_512x512.ffb40d5f2a96e0636f4938be2daf00ee.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_1136x640.24057a53b4b8207ac6128f5a1858a41f.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_640x1136.df18c0c33e95b50b62f822d65cd9b909.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_2688x1242.dbbf9209e64340c9d1b78823b8f8abf2.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_1242x2688.46f33d43a6ee160cfb767b7e565d3963.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_1792x828.79a7a4869dc12a14e286c382d496dfd0.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_828x1792.4ed2cf28de535595662c61587b07aa56.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_1125x2436.b4c95fe40cc182ee41709b5386a65a60.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_2436x1125.1fd86c39fec0a11f2f6b61d5a7af0f39.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_2208x1242.7e9fc39b1c37a328126323bbe8cd404b.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_1242x2208.d8bfb76284287658cab36f271d2a2a4a.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_1334x750.ff41747f4f3bb2f9a29c2ee494815852.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_750x1334.5d0bcf1c916780f7a20f047bb6d8a30c.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_2732x2048.fa6941ee05cda926fb2fed7a5642d92e.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_2048x2732.2ca94a4a1945d2db226863dbaff1b2de.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_2388x1668.de01f138bb18af1e0db00ec6bde434d9.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_1668x2388.a5a160b95ed25c9e654d2e54edf2908e.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_2224x1668.28140d990d7a02f90d0d2a40905cb778.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_1668x2224.7df025a8aa1b981a92dffb50d067cd80.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_2048x1536.3b6c667f7b757be5cd367060e3d67edf.png"
  },
  {
    "url": "/shop-playground/assets/splash/icon_1536x2048.e58c554d58efd43594d17e49e3d4520b.png"
  },
  {
    "revision": "251f9c13528dfcfd46777172ef40302e",
    "url": "/shop-playground/index.html"
  }
];